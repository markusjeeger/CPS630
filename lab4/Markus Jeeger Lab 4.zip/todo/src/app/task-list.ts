import { ListItem } from './list-item';

export class TaskList {
	public items = [];
}
