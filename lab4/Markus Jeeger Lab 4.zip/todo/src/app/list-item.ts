export class ListItem {	
	constructor(
		public task: string,
		public complete: boolean,
		public description: string
	 ) {  }
}
