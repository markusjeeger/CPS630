import { TaskList } from './task-list';

describe('TaskList', () => {
  it('should create an instance', () => {
    expect(new TaskList()).toBeTruthy();
  });
});
