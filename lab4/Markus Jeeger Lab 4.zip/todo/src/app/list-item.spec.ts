import { ListItem } from './list-item';

describe('ListItem', () => {
  it('should create an instance', () => {
    expect(new ListItem()).toBeTruthy();
  });
});
